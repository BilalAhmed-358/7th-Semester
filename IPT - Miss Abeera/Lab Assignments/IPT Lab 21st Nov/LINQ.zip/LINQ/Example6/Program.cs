﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Example6
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] strArray = { "Murtaza", "Umair", "Ali" , "Zeeshan" };
            string[] strArray2 = { "Ali", "Faizan", "Maria" , "Umair" };

            var ans = (from i1 in strArray
                       from i2 in strArray2
                       where i2 == i1
                       select i1);
            // Lambda expression
            var ans2 = strArray.Where(s => strArray2.Any(s2 => s2 == s));

            foreach (string result in ans)
                Console.WriteLine(result);
            Console.WriteLine("*");
            foreach (string result in ans2)
                Console.WriteLine(result);

            Console.ReadKey();
        }
    }
}
