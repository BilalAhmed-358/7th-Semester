﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Example3
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Employee> employees = new List<Employee>();
            Employee emp1 = new Employee { Name = "Ahad", Skills = new List<string> { "C", "C++", "Java" } };
            Employee emp2 = new Employee { Name = "Ahmed", Skills = new List<string> { "SQL Server", "C#", "ASP.NET" } };
            Employee emp3 = new Employee { Name = "Aslam", Skills = new List<string> { "C#", "ASP.NET MVC", "Windows Azure", "SQL Server" } };
            employees.Add(emp1);
            employees.Add(emp2);
            employees.Add(emp3);

            IEnumerable<List<String>> resultSelect = (from e in employees
                                                      select e.Skills);
            //employees.Select(e => e.Skills);

            Console.WriteLine("**************** Select ******************");

            // Two foreach loops are required to iterate through the results
            // because the query returns a collection of arrays.
            foreach (List<String> skillList in resultSelect)
            {
                foreach (string skill in skillList)
                {
                    Console.WriteLine(skill);
                }
                Console.WriteLine();
            }

            IEnumerable<string> resultSelectMany = employees.SelectMany(emp => emp.Skills);

            Console.WriteLine("**************** SelectMany ******************");

            // Only one foreach loop is required to iterate through the results 
            // since query returns a one-dimensional collection.
            foreach (string skill in resultSelectMany)
            {
                Console.WriteLine(skill);
            }


            Console.ReadKey();
        }
    }

    class Employee
    {
        public string Name { get; set; }
        public List<string> Skills { get; set; }
    }
}
