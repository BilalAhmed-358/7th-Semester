﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Example1
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Customers> customers = new List<Customers>();
            customers.Add(new Customers("A", "PK"));
            customers.Add(new Customers("B", "USA"));
            customers.Add(new Customers("C", "CAN"));
            customers.Add(new Customers("D", "UK"));


            var myCustomers = from c in customers
                              where c.Region == "PK"
                              select c;

            foreach (Customers c in myCustomers)
                Console.WriteLine(c.Name);

            Console.Read();   
        }
    }

    public class Customers
    {
        public string Region { get; set; }
        public string Name {get; set; }

        public Customers(string _Name, string _Region)
        {
            this.Name = _Name;
            this.Region = _Region;
        }
    }
}
