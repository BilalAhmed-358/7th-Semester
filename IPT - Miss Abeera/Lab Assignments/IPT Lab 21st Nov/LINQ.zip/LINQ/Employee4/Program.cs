﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Employee4
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] bands = { "ACDC", "Queen", "Aerosmith"};

            Console.WriteLine("*Select*");
            IEnumerable<char[]> charactersList = bands.Select(b => b.ToArray());
            foreach (char[] ch in charactersList)
            {
                foreach(char c in ch)
                    Console.WriteLine(c);
            }

            Console.WriteLine("*Select Many*");

            IEnumerable<char> characters = bands.SelectMany(b => b.ToArray());
            foreach(char c in characters)
            {
                Console.WriteLine(c);
            }

            Console.ReadKey();
        }
    }
}
